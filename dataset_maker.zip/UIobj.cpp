#include "UIobj.h"
#include <string>
#include <iostream>

extern int screenh;
extern int screenw;
extern int mY;
extern int mX;

bool isWithin(int targety, int targetx, int y, int x, int h, int w) {
	if (targety >= y && targety < y + h) {
		if (targetx >= x && targetx < x + w) {
			return true;
		}
	}
	return false;
}

void UIobj::SetStaticPos(int sety, int setx) {
	staticposY = sety;
	staticposX = setx;
}

bool UIobj::Disp(int y, int x, int disp_lock) {
	if (displock == disp_lock) {
		if (y == 0 && x == 0) {
			y = staticposY;
			x = staticposX;
		}
		//disp background
		if (texture) {
			texture->Disp(y, x, disprect.h, disprect.w);
		}
		//disp pictures
		for (int a = 0; a < overlay.size(); a++) {
			if (overlay[a]) {
				overlay[a]->Disp(y + overlayrect[a].y, x + overlayrect[a].x, overlayrect[a].h, overlayrect[a].w);
			}
		}
		//disp labels
		for (int a = 0; a < label.size(); a++) {
			if (centerlabel[a]) {
				label[a]->DispCenter(y + H[a], x + W[a], 1);
			}
			else {
				label[a]->Disp(y + H[a], x + W[a], 1);
			}
		}
		return true;
	}
	else {
		return false;
	}
}

bool UIobj::HoverDisp(int y, int x, int disp_lock) {
	if (displock == disp_lock) {
		if (y == 0 && x == 0) {
			y = staticposY;
			x = staticposX;
		}
		//disp background
		//disprect.y = y;
		//disprect.x = x;
		if (texture) {
			//std::cout << "A";
			texture->Disp(y, x, disprect.h, disprect.w);
		}
		//disp pictures depending on hover
		for (int a = 0; a < overlay.size(); a++) {//overlay and overlayalt always has same size
			//game.my() >= y + overlayrect[a].y && game.my() < y + overlayrect[a].y + overlayrect[a].h && game.mx() >= x + overlayrect[a].x && game.mx() < x + overlayrect[a].x + overlayrect[a].w
			if (isWithin(mY, mX, y + overlayrect[a].y, x + overlayrect[a].x, overlayrect[a].h, overlayrect[a].w)) {//mouse is hovering texture
				if (overlayalt[a]) {
					overlayalt[a]->Disp(y + overlayrect[a].y, x + overlayrect[a].x, overlayrect[a].h, overlayrect[a].w);
				}
				else if (overlay[a]) {
					overlay[a]->Disp(y + overlayrect[a].y, x + overlayrect[a].x, overlayrect[a].h, overlayrect[a].w);
				}
			}
			else {
				if (overlay[a]) {
					overlay[a]->Disp(y + overlayrect[a].y, x + overlayrect[a].x, overlayrect[a].h, overlayrect[a].w);
				}
			}
		}
		//disp labels
		for (int a = 0; a < label.size(); a++) {
			if (centerlabel[a]) {
				label[a]->DispCenter(y + H[a], x + W[a], 1);
			}
			else {
				label[a]->Disp(y + H[a], x + W[a], 1);
			}
		}
		return true;
	}
	else {
		return false;
	}
}

void UIobj::SetTexture(std::string filename, int h, int w) {
	Cleanup();
	texture = new Texture;
	texture->LoadTexture(filename);//clean up in texture class

	SetBlank(h, w);
}

void UIobj::RedSwapLoad(std::string filename, int h, int w, int R, int G, int B, int A) {
	Cleanup();
	texture = new Texture;
	texture->RedSwapLoad(filename, R, G, B, A);
	SetBlank(h, w);
}

void UIobj::SetTextureFromSurface(SDL_Surface* surface, int h, int w) {
	Cleanup();
	texture = new Texture;
	texture->FromSurface(surface);//clean up in texture class

	SetBlank(h, w);
}

void UIobj::SetAsMenu(std::string style, int h, int w, int exitnum) {
	Cleanup();
	if (h - 2 * menustylesize >= 0 && w - 2 * menustylesize >= 0) {
		texture = new Texture;
		texture->MakeMenu(style, h - 2 * menustylesize, w - 2 * menustylesize, exitnum);
	}

	SetBlank(h, w);
}

void UIobj::SetBlank(int h, int w, int y, int x) {
	disprect.y = y;
	disprect.x = x;
	disprect.h = h;
	disprect.w = w;
	NewCollider(y, x, h, w);
}

void UIobj::NewLabel(std::string text, int size, int h, int w, bool center, double* my_val, SDL_Color Color, TTF_Font** Font, std::string* label_ptr) {
	label.push_back(new Text);
	label.back()->NewLabel(text, size, Font, Color, my_val, label_ptr);
	H.push_back(h);
	W.push_back(w);
	centerlabel.push_back(center);
}

void UIobj::NewOverlay(Texture* existingtexture, int ypos, int xpos, int h, int w, Texture* alttexture) {
	if (existingtexture != nullptr && existingtexture) {
		overlay.push_back(existingtexture);
		overlayalt.push_back(alttexture);
		SDL_Rect setto;
		setto.y = ypos;
		setto.x = xpos;
		setto.h = h;
		setto.w = w;
		overlayrect.push_back(setto);
		localoverlay.push_back(false);
	}
}

void UIobj::NewStolenOverlay(Texture* existingtexture, int ypos, int xpos, int h, int w, Texture* alttexture) {
	if (existingtexture != nullptr && existingtexture) {
		overlay.push_back(existingtexture);
		overlayalt.push_back(alttexture);
		SDL_Rect setto;
		setto.y = ypos;
		setto.x = xpos;
		setto.h = h;
		setto.w = w;
		overlayrect.push_back(setto);
		localoverlay.push_back(true);
	}
}

void UIobj::NewLoadedOverlay(std::string filename, int ypos, int xpos, int h, int w, std::string filenamealt) {
	overlay.push_back(new Texture);
	overlay.back()->LoadTexture(filename);
	if (filenamealt != "") {
		overlayalt.push_back(new Texture);
		overlayalt.back()->LoadTexture(filenamealt);
	}
	else {
		overlayalt.push_back(nullptr);
	}
	SDL_Rect setto;
	setto.y = ypos;
	setto.x = xpos;
	setto.h = h;
	setto.w = w;
	overlayrect.push_back(setto);
	localoverlay.push_back(true);
}

void UIobj::NewMenuOverlay(std::string style, int ypos, int xpos, int h, int w, int exitnum, std::string altstyle) {
	overlay.push_back(new Texture);
	overlay.back()->MakeMenu(style, h - 2 * menustylesize, w - 2 * menustylesize, exitnum);
	if (altstyle != "") {
		overlayalt.push_back(new Texture);
		overlayalt.back()->MakeMenu(altstyle, h - 2 * menustylesize, w - 2 * menustylesize, exitnum);
	}
	else {
		overlayalt.push_back(nullptr);
	}
	SDL_Rect setto;
	setto.y = ypos;
	setto.x = xpos;
	setto.h = h;
	setto.w = w;
	overlayrect.push_back(setto);
	localoverlay.push_back(true);
}

void UIobj::MoveOverlay(int whichoverlay, int ypos, int xpos, int h, int w) {
		SDL_Rect setto;
		setto.y = ypos;
		setto.x = xpos;
		setto.h = h;
		setto.w = w;
		if (overlayrect.size() > whichoverlay) {
			overlayrect[whichoverlay] = setto;
		}
}

int UIobj::Collide(int ypos, int xpos) {
	ypos -= staticposY;
	xpos -= staticposX;
	for (int a = collider.size() - 1; a >= 0; a--) {
		if (CollideWith(a, ypos, xpos)) {
			//std::cout << a << "\n";
			if (colliderfunc.size() > a && colliderfunc[a]) {//also check if function is ok
				colliderfunc[a]();
			}
			return a;
		}
	}
	return -1;
}

bool UIobj::CollideWith(int whichcollider, int ypos, int xpos) {
	if (whichcollider >= 0 && whichcollider < collider.size()) {
		if (isWithin(ypos, xpos, collider[whichcollider].y, collider[whichcollider].x, collider[whichcollider].h, collider[whichcollider].w)) {
			return true;
		}
	}
	return false;
}

void UIobj::NewCollider(int ypos, int xpos, int h, int w, void (*clickfunc)(), int ID, double data) {
	SDL_Rect setto;
	setto.y = ypos;
	setto.x = xpos;
	setto.h = h;
	setto.w = w;
	collider.push_back(setto);
	colliderID.push_back(ID);
	colliderData.push_back(data);
	colliderfunc.push_back(clickfunc);
}

void UIobj::MoveCollider(int whichcollider, int y, int x) {
	if (whichcollider >= 0 && whichcollider < collider.size()) {
		collider[whichcollider].y = y;
		collider[whichcollider].x = x;
	}
	if (whichcollider == 0) {
		for (int a = 1; a < collider.size(); a++) {
			collider[a].y += y - disprect.y;
			collider[a].x += x - disprect.x;
		}
		disprect.y = y;
		disprect.x = x;
	}
}

void UIobj::ResizeCollider(int whichcollider, int h, int w) {
	if (whichcollider >= 0 && whichcollider < collider.size()) {
		if (h > 0) {
			collider[whichcollider].h = h;
		}
		if (w > 0) {
			collider[whichcollider].w = w;
		}
	}
	if (whichcollider == 0) {
		if (h > 0) {
			disprect.h = h;
		}
		if (w > 0) {
			disprect.w = w;
		}
	}
}

int UIobj::GetColliderID(int whichcollider) {
	if (whichcollider >= 0 && whichcollider < colliderID.size()) {
		return colliderID[whichcollider];
	}
	return -1;
}

double UIobj::GetColliderData(int whichcollider) {
	if (whichcollider >= 0 && whichcollider < colliderData.size()) {
		return colliderData[whichcollider];
	}
	return 0;
}

int UIobj::AmountOfOverlays() {
	return overlay.size();
}

int UIobj::AmountOfColliders() {
	return collider.size();
}

void UIobj::Cleanup() {
	if (texture) {
		texture->Cleanup();
		delete texture;
		texture = nullptr;
	}
	int end = label.size();
	for (int a = 0; a < end; a++) {
		if (label[a]) {
			label[a]->Cleanup();
			delete label[a];
			label[a] = nullptr;
		}
	}

	label.clear();
	H.clear();
	W.clear();
	centerlabel.clear();

	//end = overlay.size();
	//for (int a = 0; a < end; a++) {
	//	overlay[a].Destroy();
	//}

	end = overlay.size();
	for (int a = 0; a < end; a++) {
		if (localoverlay[a]) {
			if (overlay[a]) {
				overlay[a]->Cleanup();
				delete overlay[a];
				overlay[a] = nullptr;
			}
			if (overlayalt[a]) {
				overlayalt[a]->Cleanup();
				delete overlayalt[a];
				overlayalt[a] = nullptr;
			}
		}
	}

	overlay.clear();
	overlayalt.clear();
	overlayrect.clear();
	localoverlay.clear();
	collider.clear();
	colliderID.clear();
	colliderData.clear();
	colliderfunc.clear();
}