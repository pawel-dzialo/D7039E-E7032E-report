#pragma once
#include <SDL.h>
#include "Texture.h"
#include "Text.h"
#include "Defines.h"
#include <sstream>
#include <vector>
//I was drunk AF when I added this file, might have to change a lot of things when I sober up
//Nah this is pretty decent work /sobered up me
//ok wait this is fundamentally flawed
//well it is quite ok now

extern SDL_Color Black;
extern TTF_Font* Cardo;
extern TTF_Font* Cardo32;
extern TTF_Font* CardoB;
extern TTF_Font* Sans;

class UIobj
{
public:
	void SetStaticPos(int sety, int setx);
	bool Disp(int y = 0, int x = 0, int disp_lock = -1);//w and h static?
	bool HoverDisp(int y = 0, int x = 0, int disp_lock = -1);
	void SetTexture(std::string filename, int h, int w);
	void RedSwapLoad(std::string filename, int h, int w, int R, int G, int B, int A = 255);
	void SetTextureFromSurface(SDL_Surface* surface, int h, int w);
	void SetAsMenu(std::string style, int h, int w, int exitnum = 0);
	void SetBlank(int h = -1, int w = -1, int y = 0, int x = 0);
	void NewLabel(std::string text, int size, int h, int w, bool center = false, double* my_val = nullptr, SDL_Color Color = Black, TTF_Font** Font = &CardoB, std::string* label_ptr = nullptr);
	void NewOverlay(Texture* existingtexture, int ypos, int xpos, int h, int w, Texture* alttexture = nullptr);
	void NewStolenOverlay(Texture* existingtexture, int ypos, int xpos, int h, int w, Texture* alttexture = nullptr);
	void MoveOverlay(int whichoverlay, int ypos, int xpos, int h, int w);
	void NewLoadedOverlay(std::string filename, int ypos, int xpos, int h, int w, std::string filenamealt = "");
	void NewMenuOverlay(std::string style, int ypos, int xpos, int h, int w, int exitnum = 0, std::string altstyle = "");
	void NewCollider(int ypos, int xpos, int h, int w, void (*clickfunc)() = nullptr, int ID = -1, double data = 0);
	int Collide(int ypos, int xpos);
	bool CollideWith(int whichcollider, int ypos, int xpos);
	void MoveCollider(int whichcollider, int y, int x);
	void ResizeCollider(int whichcollider, int h = -1, int w = -1);
	int GetColliderID(int whichcollider);
	double GetColliderData(int whichcollider);
	int AmountOfOverlays();//returns the size of the overlay vector
	int AmountOfColliders();//returns the size of the collider vector, remember that the UIobj itself is a collider, so it "starts" at 1
	void SetDispLock(int set_displock) {//WTF?? Vad �r detta och varf�r �r det n�gonsin anv�ndbart???
		displock = set_displock;
	}
	int GetDispLock() {
		return displock;
	}
	void Cleanup();
	~UIobj() {
		Cleanup();
	}
	int TW() { return disprect.w; }
	int TH() { return disprect.h; }
	int TY() { return disprect.y; }
	int TX() { return disprect.x; }
	bool isactive = false;
private:
	int displock = -1;
	SDL_Rect disprect;
	Texture* texture = nullptr;

	int staticposY = 0;
	int staticposX = 0;

	std::vector<Text*> label; //moved to vector, maxlabels obsolete
	std::vector<int> H;
	std::vector<int> W;
	std::vector<bool> centerlabel;

	std::vector<Texture*> overlay;
	std::vector<Texture*> overlayalt;
	std::vector<bool> localoverlay;
	std::vector<SDL_Rect> overlayrect;
	std::vector<SDL_Rect> collider;//button, IsWithin() true or false
	std::vector<int> colliderID;
	std::vector<double> colliderData;
	std::vector<void (*)()> colliderfunc;
	//int labelc = 0;//labelcounter
};


/*
texture
numbers and text
maybe additional textures on top
buttons with scripts
draggable
*/
