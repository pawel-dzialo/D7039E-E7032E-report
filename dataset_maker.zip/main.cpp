#define SDL_MAIN_HANDLED

#include "Global.h"

extern SDL_Renderer* renderer;
extern SDL_Window* window;
extern SDL_Event mainevent;
extern TTF_Font* CardoB;

extern Dataset data;
extern int screenh;
extern int screenw;
extern int mY;
extern int mX;
extern unsigned char clickbuffer[256];
extern unsigned char threadcontroller;
extern unsigned char threadrunning_python;
extern unsigned char threadrunning_dataset;

extern std::vector<UIobj*> menu;
extern std::vector<Dataset*> dataset;

extern Texture* windowtexture;

int frameDelay = 1000 / tickspeed;//1/tickspeed of 1000ms, means that game tick is tickspeed times per second
int fpscounter = 0;
int fps = 0;

bool running = true;

//header until I move stuff
void MakeTopMenu(UIobj* target);
void MakeLeftMenu(UIobj* target);
void MakeRightMenu(UIobj* target);

void ToPy(std::string filename, std::string contents) {
	filename = "data/" + filename + ".py";
	std::ofstream file;
	file.open(filename);
	if (file.is_open()) {
		file << contents;
		file.close();
	}
}

bool Clicked(unsigned char button) {
	if (clickbuffer[button] & 0b00000001) {//currently clicking
		if (!(clickbuffer[button] & 0b00000010)) {//just clicked
			clickbuffer[button] = clickbuffer[button] | 0b00000010;
			return true;
		}
	}
	else {//not clicking
		clickbuffer[button] = clickbuffer[button] & 0b11111101;
	}
	return false;
}

void PythonLoop() {
	threadrunning_python = 1;

	//ToPy("pytest", "a=1\nprint('Hello')");

	//Py_Initialize();

	//FILE* pyfile = _Py_fopen("data/pytest.py", "r");

	//if (pyfile) {
	//	PyRun_SimpleFile(pyfile, "data/pytest.py");
	//	//fclose(pyfile);
	//}

	//PyRun_SimpleString("print(a)");

	//Py_Finalize();

	//std::thread mapthread(&Game::LoadMapThread, this, new Map, b, maptoload.front().n[0], maptoload.front().n[1], maptoload.front().n[2]);
	//mapthread.detach();

	//threadcontroller = 0b00000001;
	//std::thread pythread(PythonLoop);
	//pythread.detach();

	//system("pause>nul");

	//threadcontroller = threadcontroller & 0b11111110;

	Py_Initialize();

	while (threadcontroller & 0b00000001) {
		PyRun_SimpleString("print('Python says \\\"Hello\\\"')");
		Sleep(100);
	}

	Py_Finalize();
	threadrunning_python = 2;
}

void MakeDataset(Dataset* datapointer) {
	threadrunning_dataset = 1;
	std::string filename;

	for (int a = 1; a <= 21; a++) {
		if (threadcontroller & 0b00000010) {
			filename = "data/raw/chb01_";
			if (a < 10) {
				filename += '0';
			}
			filename += std::to_string(a);
			filename += ".edf";

			datapointer->ImportEDF(filename);
			datapointer->LoadLabels(filename);
			datapointer->MakeWindows();
			datapointer->SortDataset();
			datapointer->RemoveJunk();
			if (a % 5 == 0) {
				datapointer->BalanceDataset();
			}
		}
	}
	datapointer->BalanceDataset();
	datapointer->ExportData("data/output/chb01.txt");
	datapointer->Cleanup();
	threadrunning_dataset = 2;
}

void MakeButton(UIobj* target, void (*clickfunc)(), std::string text, int y, int x, double* tracknumber = nullptr) {
	if (target) {
		target->NewMenuOverlay("simple-blue", y, x - 64, 64, 128, 0, "simple-blue2");
		target->NewLabel(text, 24, y + 32, x, true, tracknumber);
		target->NewCollider(y, x - 64, 64, 128, clickfunc);
	}
}

void PrintHello() {
	std::cout << "Hello\n";
}

void MakeDatasetThread() {
	if (threadcontroller & 0b00000010) {
		threadcontroller = threadcontroller & 0b11111101;
	}
	else if (threadrunning_dataset == 0) {
		threadcontroller = threadcontroller | 0b00000010;

		dataset.push_back(new Dataset);

		if (menu.size() > 1 && menu[1]) {
			MakeLeftMenu(menu[1]);
			MakeButton(menu[1], nullptr, "Size: ", 120 + 64 + 8, 150, &dataset.back()->datasetsize);
		}

		std::thread datathread(MakeDataset, dataset.back());
		datathread.detach();
	}
}

void TogglePython() {
	if (threadcontroller & 0b00000001) {
		threadcontroller = threadcontroller & 0b11111110;
	}
	else if(threadrunning_python == 0){
		threadcontroller = threadcontroller | 0b00000001;
		std::thread pythread(PythonLoop);
		pythread.detach();
	}
}

void MakeTopMenu(UIobj* target) {
	//top menu
	if (target) {
		target->SetAsMenu("simple-blue", 80, screenw);
		target->SetStaticPos(0, 0);
	}
}

void MakeLeftMenu(UIobj* target) {
	//left menu
	if (target) {
		target->SetAsMenu("simple-blue", screenh - 80 + 1, 300);
		target->SetStaticPos(80 - 1, 0);
		MakeButton(target, MakeDatasetThread, "Make Dataset", 120, 150);
	}
}

void MakeRightMenu(UIobj* target) {
	//right menu
	if (target) {
		target->SetAsMenu("simple-blue", screenh - 80 + 1, 300);
		target->SetStaticPos(80 - 1, screenw - 300);
		MakeButton(target, TogglePython, "Python Test", 120, 150);
	}
}

void ViewRandomImage(Dataset* datapointer) {
	if (datapointer) {
		if (datapointer->datasetsize > 0) {
			int label = rand() % 3;
			if (windowtexture) {
				windowtexture->Cleanup();
			}
			windowtexture = datapointer->GetWindowTexture(label);
		}
	}
}

void ViewRandomImageRandom() {
	if(dataset.size() > 0) {
		int num = rand() % dataset.size();
		ViewRandomImage(dataset[num]);
	}
}

void Load() {
	CardoB = TTF_OpenFont("data/font/Cardo-Bold.ttf", 32);

	menu.push_back(new UIobj);
	MakeTopMenu(menu.back());
	menu.push_back(new UIobj);
	MakeLeftMenu(menu.back());
	menu.push_back(new UIobj);
	MakeRightMenu(menu.back());

}

void Cleanup() {
	threadcontroller = 0;//all threads will close shortly

	for (int a = 0; a < menu.size(); a++) {
		if (menu[a]) {
			menu[a]->Cleanup();
			delete menu[a];
			menu[a] = nullptr;
		}
	}
	menu.clear();

	if (windowtexture) {
		windowtexture->Cleanup();
	}

	if (window) {
		SDL_DestroyWindow(window);
	}
	if (renderer) {
		SDL_DestroyRenderer(renderer);
	}
	TTF_CloseFont(CardoB);
	SDLNet_Quit();
	Mix_CloseAudio();
	TTF_Quit();
	IMG_Quit();
	SDL_Quit();
}

void TakeInput() {
	//take input etc
	SDL_GetMouseState(&mX, &mY);
	for (int a = 0; a < 256; a++) {
		if (GetAsyncKeyState(a)) {
			clickbuffer[a] = clickbuffer[a] | 0b00000001;
		}
		else {
			clickbuffer[a] = clickbuffer[a] & 0b11111110;
		}
	}
	SDL_PollEvent(&mainevent);
	if (mainevent.type == SDL_QUIT) {
		running = false;
	}
	if (Clicked(VK_TAB)) {
		running = false;
	}
	if (Clicked(0x01)) {
		for (int a = 0; a < menu.size(); a++) {
			if (menu[a]) {
				menu[a]->Collide(mY, mX);
			}
		}
	}
}

void Update() {
	if (threadrunning_python == 2) {//finished python
		threadrunning_python = 0;
	}
	if (threadrunning_dataset == 2) {//finished dataset
		threadrunning_dataset = 0;
		if (menu.size() > 1 && menu[1]) {
			MakeButton(menu[1], ViewRandomImageRandom, "View random", 120 + (64 + 8) * 2, 150);
		}
	}
}

void Render() {
	fpscounter++;
	SDL_RenderClear(renderer);//clear old stuff

	//View on screen
	for (int a = 0; a < menu.size(); a++) {
		if (menu[a]) {
			menu[a]->HoverDisp();
		}
	}
	if (windowtexture) {
		windowtexture->Disp(screenh / 2 - 360, screenw / 2 - 35, 720, 69);
	}

	SDL_RenderPresent(renderer);//send to screen
}

int main(int argc, char* argv[]) {
	srand(time(0));//seed the random number generator

	if (SDL_Init(SDL_INIT_EVERYTHING) == 0 && TTF_Init() == 0 && SDLNet_Init() == 0 && Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, 2, 4096) >= 0) {
		//ok
		window = SDL_CreateWindow("Friend", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, screenw, screenh, 0);
		if (window) {
			//still ok
			renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
			SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");//default to pixel art. "0" is for pixel art, "1" is for text
			if (renderer) {
				//everything is ok

				Load();

				unsigned int frameStart = SDL_GetTicks();
				unsigned int frameTime = frameDelay;

				unsigned int fpsframeStart = SDL_GetTicks();
				unsigned int fpsframeTime = 1000;
				while (running) {//game main loop
					if (frameTime >= frameDelay) {//only do this tickspeed times per second
						frameStart = SDL_GetTicks();

						TakeInput();
						Update();
						Render();
					}
					if (fpsframeTime >= 1000) {//only do this once per second
						fpsframeStart = SDL_GetTicks();
						fps = fpscounter;
						fpscounter = 0;
					}
					
					//for online features, check server as often as you can
					//ConnectionEvents();

					//to unbind FPS from ticks, move Render function (and maybe TakeInput as well) outside of the if-statement

					frameTime = SDL_GetTicks() - frameStart;
					fpsframeTime = SDL_GetTicks() - fpsframeStart;
				}
			}
		}
	}

	Cleanup();

	return 0;
}