#include "Texture.h"

#include <SDL_ttf.h>
#include <iostream>
#include <math.h>

#include "Defines.h"

extern SDL_Renderer* renderer;
extern TTF_Font* CardoB;

extern int screenh;
extern int screenw;
extern int mY;
extern int mX;

void Texture::LoadTexture(std::string filename) {
	if (texture) {
		Cleanup();
	}
	texture = IMG_LoadTexture(renderer, filename.c_str());
	SDL_QueryTexture(texture, NULL, NULL, &baserect.w, &baserect.h);
}

void Texture::FromSurface(SDL_Surface* surface) {
	if (texture) {
		Cleanup();
	}
	if (surface) {
		texture = SDL_CreateTextureFromSurface(renderer, surface);
		SDL_QueryTexture(texture, NULL, NULL, &baserect.w, &baserect.h);
	}
}

void Texture::Label(std::string text) {
	if (texture) {
		Cleanup();
	}
	SDL_Surface* textSurface = TTF_RenderText_Blended(CardoB, text.c_str(), { 255, 255, 255 });
	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");
	FromSurface(textSurface);
	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
	SDL_FreeSurface(textSurface);
}

void Texture::RedSwapLoad(std::string filename, int R, int G, int B, int A) {
	SDL_Surface* img = IMG_Load(filename.c_str());
	if (img) {
		SDL_Surface* surface = SDL_ConvertSurfaceFormat(img, SDL_PIXELFORMAT_RGBA32, 0);
		uint8_t* pixels = (uint8_t*)surface->pixels;
		//pixels[4 * (a * surface->w + b) + 0] = R;
		//pixels[4 * (a * surface->w + b) + 1] = G;
		//pixels[4 * (a * surface->w + b) + 2] = B;
		//pixels[4 * (a * surface->w + b) + 3] = A;

		//for (int a = 0; a < 3; a++) {
		//	for (int b = 0; b < 3; b++) {
		//		std::cout << (int)pixels[4 * (a * surface->w + b) + 0] << " " << (int)pixels[4 * (a * surface->w + b) + 1] << " " << (int)pixels[4 * (a * surface->w + b) + 2] << " " << (int)pixels[4 * (a * surface->w + b) + 3] << "\n";
		//	}
		//}
		int nr;
		int ng;
		int nb;
		int na;
		double lightmod = 1.1;
		double darkmod = 0.9;
		for (int a = 0; a < surface->h; a++) {
			for (int b = 0; b < surface->w; b++) {
				nr = 0;
				ng = 0;
				nb = 0;
				na = 0;
				if (pixels[4 * (a * surface->w + b) + 0] == 255 && pixels[4 * (a * surface->w + b) + 1] == 0 && pixels[4 * (a * surface->w + b) + 2] == 0 && pixels[4 * (a * surface->w + b) + 3] > 0) {//main color
					nr = R;
					ng = G;
					nb = B;
					na = A;
				}
				else if (pixels[4 * (a * surface->w + b) + 0] == 0 && pixels[4 * (a * surface->w + b) + 1] == 255 && pixels[4 * (a * surface->w + b) + 2] == 0 && pixels[4 * (a * surface->w + b) + 3] > 0) {//light contrast
					nr = R * lightmod;
					ng = G * lightmod;
					nb = B * lightmod;
					na = A;
				}
				else if (pixels[4 * (a * surface->w + b) + 0] == 0 && pixels[4 * (a * surface->w + b) + 1] == 0 && pixels[4 * (a * surface->w + b) + 2] == 255 && pixels[4 * (a * surface->w + b) + 3] > 0) {//dark contrast
					nr = R * darkmod;
					ng = G * darkmod;
					nb = B * darkmod;
					na = A;
				}
				if (nr != 0 || ng != 0 || nb != 0 || na != 0) {
					if (nr < 0) {
						nr = 0;
					}
					if (nr > 255) {
						nr = 255;
					}
					if (ng < 0) {
						ng = 0;
					}
					if (ng > 255) {
						ng = 255;
					}
					if (nb < 0) {
						nb = 0;
					}
					if (nb > 255) {
						nb = 255;
					}
					if (na < 0) {
						na = 0;
					}
					if (na > 255) {
						na = 255;
					}
					pixels[4 * (a * surface->w + b) + 0] = nr;
					pixels[4 * (a * surface->w + b) + 1] = ng;
					pixels[4 * (a * surface->w + b) + 2] = nb;
					pixels[4 * (a * surface->w + b) + 3] = na;
				}
			}
		}

		//PICTURE HAS TO HAVE ALPHA CHANNEL ENABLED FOR SURFACE TO HAVE IT

		FromSurface(surface);

		SDL_FreeSurface(surface);
	}
	SDL_FreeSurface(img);
}

void Texture::MakeMenu(std::string style, int H, int W, int exitnum) {
	style = "data/textures/UI/menustyles/" + style;
	std::string bullshit;
	if (texture) {
		Cleanup();
	}
	if (H < 0) {
		H = 0;
	}
	if (H > screenh) {
		H = screenh;
	}
	if (W < 0) {
		W = 0;
	}
	if (W > screenw) {
		W = screenw;
	}
	H = H + menustylesize * 2;
	W = W + menustylesize * 2;
	SDL_Surface* surface = SDL_CreateRGBSurfaceWithFormat(0, W, H, 32, SDL_PIXELFORMAT_RGBA32);
	if (surface) {
		uint8_t* pixels = (uint8_t*)surface->pixels;

		//for (int a = 0; a < H; a++) {
		//	for (int b = 0; b < W; b++) {
		//		pixels[4 * (a * W + b) + 0] = 80;//R
		//		pixels[4 * (a * W + b) + 1] = 20;//G
		//		pixels[4 * (a * W + b) + 2] = 10;//B
		//		pixels[4 * (a * W + b) + 3] = 255;//A
		//	}
		//}

		bullshit = style + "/content.png";
		SDL_Surface* imgcontent = IMG_Load(bullshit.c_str());
		SDL_Surface* surfacecontent = nullptr;
		uint8_t* pixelscontent = nullptr;
		if (imgcontent) {
			surfacecontent = SDL_ConvertSurfaceFormat(imgcontent, SDL_PIXELFORMAT_RGBA32, 0);
			pixelscontent = (uint8_t*)surfacecontent->pixels;
			for (int a = 0; a < H - menustylesize * 2; a++) {
				for (int b = 0; b < W - menustylesize * 2; b++) {
					pixels[4 * ((a + menustylesize) * W + (b + menustylesize)) + 0] = pixelscontent[0];//R
					pixels[4 * ((a + menustylesize) * W + (b + menustylesize)) + 1] = pixelscontent[1];//G
					pixels[4 * ((a + menustylesize) * W + (b + menustylesize)) + 2] = pixelscontent[2];//B
					pixels[4 * ((a + menustylesize) * W + (b + menustylesize)) + 3] = pixelscontent[3];//A
				}
			}
			//for (int a = 0; a < H; a++) {
			//	for (int b = 0; b < W; b++) {
			//		pixels[4 * ((a + menustylesize) * W + (b + menustylesize)) + 0] = pixelscontent[0];//R
			//		pixels[4 * ((a + menustylesize) * W + (b + menustylesize)) + 1] = pixelscontent[1];//G
			//		pixels[4 * ((a + menustylesize) * W + (b + menustylesize)) + 2] = pixelscontent[2];//B
			//		pixels[4 * ((a + menustylesize) * W + (b + menustylesize)) + 3] = pixelscontent[3];//A
			//	}
			//}
			//float darkmod = 0;
			//for (int a = 0; a < H; a++) {
			//	for (int b = 0; b < W; b++) {
			//		darkmod = float(rand() % 100 + 450) / 500;
			//		pixels[4 * (a * W + b) + 0] = ((pixelscontent[0] * darkmod > 255) ? 255 : pixelscontent[0] * darkmod);//R
			//		pixels[4 * (a * W + b) + 1] = ((pixelscontent[1] * darkmod > 255) ? 255 : pixelscontent[1] * darkmod);//G
			//		pixels[4 * (a * W + b) + 2] = ((pixelscontent[2] * darkmod > 255) ? 255 : pixelscontent[2] * darkmod);//B
			//		pixels[4 * (a * W + b) + 3] = pixelscontent[3];//A
			//	}
			//}

			//SDL_FreeSurface(surfacecontent);//cleaned up later
		}
		//SDL_FreeSurface(imgcontent);//cleaned up later

		bullshit = style + "/corner.png";
		SDL_Surface* imgcorner = IMG_Load(bullshit.c_str());
		if (imgcorner) {
			SDL_Surface* surfacecorner = SDL_ConvertSurfaceFormat(imgcorner, SDL_PIXELFORMAT_RGBA32, 0);
			uint8_t* pixelscorner = (uint8_t*)surfacecorner->pixels;
			if (exitnum != 1) {
				for (int a = 0; a < menustylesize; a++) {//up right
					for (int b = 0; b < menustylesize; b++) {
						if (pixelscorner[4 * (a * menustylesize + b) + 3] > 0) {
							pixels[4 * (a * W + (W - menustylesize + b)) + 0] = pixelscorner[4 * (a * menustylesize + b) + 0];//R
							pixels[4 * (a * W + (W - menustylesize + b)) + 1] = pixelscorner[4 * (a * menustylesize + b) + 1];//G
							pixels[4 * (a * W + (W - menustylesize + b)) + 2] = pixelscorner[4 * (a * menustylesize + b) + 2];//B
							pixels[4 * (a * W + (W - menustylesize + b)) + 3] = pixelscorner[4 * (a * menustylesize + b) + 3];//A
						}
						else {
							pixels[4 * (a * W + (W - menustylesize + b)) + 3] = 0;
						}
					}
				}
			}
			if (exitnum != 2) {
				for (int a = 0; a < menustylesize; a++) {//down right
					for (int b = 0; b < menustylesize; b++) {
						if (pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + b) + 3] > 0) {
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 0] = pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + b) + 0];//R
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 1] = pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + b) + 1];//G
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 2] = pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + b) + 2];//B
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 3] = pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + b) + 3];//A
						}
						else {
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 3] = 0;
						}
					}
				}
			}
			if (exitnum != 3) {
				for (int a = 0; a < menustylesize; a++) {//down left
					for (int b = 0; b < menustylesize; b++) {
						if (pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 3] > 0) {
							pixels[4 * ((H - menustylesize + a) * W + b) + 0] = pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 0];//R
							pixels[4 * ((H - menustylesize + a) * W + b) + 1] = pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 1];//G
							pixels[4 * ((H - menustylesize + a) * W + b) + 2] = pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 2];//B
							pixels[4 * ((H - menustylesize + a) * W + b) + 3] = pixelscorner[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 3];//A
						}
						else {
							pixels[4 * ((H - menustylesize + a) * W + b) + 3] = 0;
						}
					}
				}
			}
			if (exitnum != 4) {
				for (int a = 0; a < menustylesize; a++) {//up left
					for (int b = 0; b < menustylesize; b++) {
						if (pixelscorner[4 * (a * menustylesize + (menustylesize - b - 1)) + 3] > 0) {
							pixels[4 * (a * W + b) + 0] = pixelscorner[4 * (a * menustylesize + (menustylesize - b - 1)) + 0];//R
							pixels[4 * (a * W + b) + 1] = pixelscorner[4 * (a * menustylesize + (menustylesize - b - 1)) + 1];//G
							pixels[4 * (a * W + b) + 2] = pixelscorner[4 * (a * menustylesize + (menustylesize - b - 1)) + 2];//B
							pixels[4 * (a * W + b) + 3] = pixelscorner[4 * (a * menustylesize + (menustylesize - b - 1)) + 3];//A
						}
						else {
							pixels[4 * (a * W + b) + 3] = 0;
						}
					}
				}
			}


			SDL_FreeSurface(surfacecorner);
		}
		SDL_FreeSurface(imgcorner);

		bullshit = style + "/exit.png";
		SDL_Surface* imgexit = IMG_Load(bullshit.c_str());
		if (imgexit) {
			SDL_Surface* surfaceexit = SDL_ConvertSurfaceFormat(imgexit, SDL_PIXELFORMAT_RGBA32, 0);
			uint8_t* pixelsexit = (uint8_t*)surfaceexit->pixels;
			if (exitnum == 1) {
				for (int a = 0; a < menustylesize; a++) {//up right
					for (int b = 0; b < menustylesize; b++) {
						if (pixelsexit[4 * (a * menustylesize + b) + 3] > 0) {
							pixels[4 * (a * W + (W - menustylesize + b)) + 0] = pixelsexit[4 * (a * menustylesize + b) + 0];//R
							pixels[4 * (a * W + (W - menustylesize + b)) + 1] = pixelsexit[4 * (a * menustylesize + b) + 1];//G
							pixels[4 * (a * W + (W - menustylesize + b)) + 2] = pixelsexit[4 * (a * menustylesize + b) + 2];//B
							pixels[4 * (a * W + (W - menustylesize + b)) + 3] = pixelsexit[4 * (a * menustylesize + b) + 3];//A
						}
						else {
							pixels[4 * (a * W + (W - menustylesize + b)) + 3] = 0;
						}
					}
				}
			}
			if (exitnum == 2) {
				for (int a = 0; a < menustylesize; a++) {//down right
					for (int b = 0; b < menustylesize; b++) {
						if (pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + b) + 3] > 0) {
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 0] = pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + b) + 0];//R
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 1] = pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + b) + 1];//G
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 2] = pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + b) + 2];//B
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 3] = pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + b) + 3];//A
						}
						else {
							pixels[4 * ((H - menustylesize + a) * W + (W - menustylesize + b)) + 3] = 0;
						}
					}
				}
			}
			if (exitnum == 3) {
				for (int a = 0; a < menustylesize; a++) {//down left
					for (int b = 0; b < menustylesize; b++) {
						if (pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 3] > 0) {
							pixels[4 * ((H - menustylesize + a) * W + b) + 0] = pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 0];//R
							pixels[4 * ((H - menustylesize + a) * W + b) + 1] = pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 1];//G
							pixels[4 * ((H - menustylesize + a) * W + b) + 2] = pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 2];//B
							pixels[4 * ((H - menustylesize + a) * W + b) + 3] = pixelsexit[4 * ((menustylesize - a - 1) * menustylesize + (menustylesize - b - 1)) + 3];//A
						}
						else {
							pixels[4 * ((H - menustylesize + a) * W + b) + 3] = 0;
						}
					}
				}
			}
			if (exitnum == 4) {
				for (int a = 0; a < menustylesize; a++) {//up left
					for (int b = 0; b < menustylesize; b++) {
						if (pixelsexit[4 * (a * menustylesize + (menustylesize - b - 1)) + 3] > 0) {
							pixels[4 * (a * W + b) + 0] = pixelsexit[4 * (a * menustylesize + (menustylesize - b - 1)) + 0];//R
							pixels[4 * (a * W + b) + 1] = pixelsexit[4 * (a * menustylesize + (menustylesize - b - 1)) + 1];//G
							pixels[4 * (a * W + b) + 2] = pixelsexit[4 * (a * menustylesize + (menustylesize - b - 1)) + 2];//B
							pixels[4 * (a * W + b) + 3] = pixelsexit[4 * (a * menustylesize + (menustylesize - b - 1)) + 3];//A
						}
						else {
							pixels[4 * (a * W + b) + 3] = 0;
						}
					}
				}
			}

			SDL_FreeSurface(surfaceexit);
		}
		SDL_FreeSurface(imgexit);

		bullshit = style + "/side.png";
		SDL_Surface* imgside = IMG_Load(bullshit.c_str());
		if (imgside) {
			SDL_Surface* surfaceside = SDL_ConvertSurfaceFormat(imgside, SDL_PIXELFORMAT_RGBA32, 0);
			uint8_t* pixelsside = (uint8_t*)surfaceside->pixels;
			for (int a = 0; a < H - menustylesize * 2; a++) {
				for (int b = 0; b < menustylesize; b++) {
					//right
					if (pixelsside[4 * b + 3] > 0) {
						pixels[4 * ((a + menustylesize) * W + (W - menustylesize + b)) + 0] = pixelsside[4 * b + 0];//R
						pixels[4 * ((a + menustylesize) * W + (W - menustylesize + b)) + 1] = pixelsside[4 * b + 1];//G
						pixels[4 * ((a + menustylesize) * W + (W - menustylesize + b)) + 2] = pixelsside[4 * b + 2];//B
						pixels[4 * ((a + menustylesize) * W + (W - menustylesize + b)) + 3] = pixelsside[4 * b + 3];//A
					}
					else {
						pixels[4 * ((a + menustylesize) * W + (W - menustylesize + b)) + 3] = 0;
					}
					//left
					if (pixelsside[4 * (menustylesize - b - 1) + 3] > 0) {
						pixels[4 * ((a + menustylesize) * W + b) + 0] = pixelsside[4 * (menustylesize - b - 1) + 0];//R
						pixels[4 * ((a + menustylesize) * W + b) + 1] = pixelsside[4 * (menustylesize - b - 1) + 1];//G
						pixels[4 * ((a + menustylesize) * W + b) + 2] = pixelsside[4 * (menustylesize - b - 1) + 2];//B
						pixels[4 * ((a + menustylesize) * W + b) + 3] = pixelsside[4 * (menustylesize - b - 1) + 3];//A
					}
					else {
						pixels[4 * ((a + menustylesize) * W + b) + 3] = 0;
					}
				}
			}
			for (int a = 0; a < menustylesize; a++) {
				for (int b = 0; b < W - menustylesize * 2; b++) {
					//down
					if (pixelsside[4 * a + 3] > 0) {
						pixels[4 * ((H - menustylesize + a) * W + (b + menustylesize)) + 0] = pixelsside[4 * a + 0];//R
						pixels[4 * ((H - menustylesize + a) * W + (b + menustylesize)) + 1] = pixelsside[4 * a + 1];//G
						pixels[4 * ((H - menustylesize + a) * W + (b + menustylesize)) + 2] = pixelsside[4 * a + 2];//B
						pixels[4 * ((H - menustylesize + a) * W + (b + menustylesize)) + 3] = pixelsside[4 * a + 3];//A
					}
					else {
						pixels[4 * ((H - menustylesize + a) * W + (b + menustylesize)) + 3] = 0;
					}
					//up
					if (pixelsside[4 * (menustylesize - a - 1) + 3] > 0) {
						pixels[4 * (a * W + (b + menustylesize)) + 0] = pixelsside[4 * (menustylesize - a - 1) + 0];//R
						pixels[4 * (a * W + (b + menustylesize)) + 1] = pixelsside[4 * (menustylesize - a - 1) + 1];//G
						pixels[4 * (a * W + (b + menustylesize)) + 2] = pixelsside[4 * (menustylesize - a - 1) + 2];//B
						pixels[4 * (a * W + (b + menustylesize)) + 3] = pixelsside[4 * (menustylesize - a - 1) + 3];//A
					}
					else {
						pixels[4 * (a * W + (b + menustylesize)) + 3] = 0;
					}
				}
			}

			SDL_FreeSurface(surfaceside);
		}
		SDL_FreeSurface(imgside);

		//float darkmod = 0;
		//for (int a = 0; a < H; a++) {
		//	for (int b = 0; b < W; b++) {
		//		darkmod = float(rand() % 100 + 450) / 500;
		//		pixels[4 * (a * W + b) + 0] = pixels[4 * (a * W + b) + 0];//R
		//		pixels[4 * (a * W + b) + 1] = pixels[4 * (a * W + b) + 1];//G
		//		pixels[4 * (a * W + b) + 2] = pixels[4 * (a * W + b) + 2];//B
		//		pixels[4 * (a * W + b) + 3] = pixels[4 * (a * W + b) + 3];//A
		//	}
		//}

		if (imgcontent) {
			//double darkmod = 0;
			//if (pixelscontent) {
			//	for (int a = 0; a < H; a++) {
			//		for (int b = 0; b < W; b++) {
			//			if (pixels[4 * (a * W + b) + 0] == pixelscontent[0] && pixels[4 * (a * W + b) + 1] == pixelscontent[1] && pixels[4 * (a * W + b) + 2] == pixelscontent[2]) {
			//				darkmod = double(rand() % 50 + 975) / 1000;
			//				pixels[4 * (a * W + b) + 0] = ((pixelscontent[0] * darkmod > 255) ? 255 : pixelscontent[0] * darkmod);//R
			//				pixels[4 * (a * W + b) + 1] = ((pixelscontent[1] * darkmod > 255) ? 255 : pixelscontent[1] * darkmod);//G
			//				pixels[4 * (a * W + b) + 2] = ((pixelscontent[2] * darkmod > 255) ? 255 : pixelscontent[2] * darkmod);//B
			//			}
			//		}
			//	}
			//}

			SDL_FreeSurface(surfacecontent);
			SDL_FreeSurface(imgcontent);
		}
		FromSurface(surface);
	}
	SDL_FreeSurface(surface);
}

SDL_Texture* Texture::StealTexture() {
	if (texture) {
		SDL_Texture* ret = texture;
		texture = nullptr;
		return ret;
	}
	else {
		return nullptr;
	}
}

void Texture::Disp(int y, int x, int h, int w, double deg, int roty, int rotx, int state, int animationwidth) {
	if (texture) {
		bool animated;// = false;
		if (h <= 0 || w <= 0) {
			h = baserect.h;
			w = baserect.w;
		}
		if (x <= screenw && x + w >= 0 && y <= screenh && y + h >= 0) {//is displayed on the screen
			disprect.h = h;
			disprect.w = w;
			disprect.y = y;
			disprect.x = x;
			if (animationwidth > 0 && state >= 0 && animationwidth * state < baserect.w) {
				animated = true;
				animationrect.h = h;
				animationrect.w = animationwidth;
				animationrect.y = 0;
				animationrect.x = animationwidth * state;
			}
			else {
				animated = false;
			}

			if (animated) {
				rotpoint.y = disprect.h / 2 + roty;
				rotpoint.x = disprect.w / 2 + rotx;
				SDL_RenderCopyEx(renderer, texture, &animationrect, &disprect, deg, &rotpoint, SDL_FLIP_NONE);
			}
			else {
				rotpoint.y = disprect.h / 2 + roty;
				rotpoint.x = disprect.w / 2 + rotx;
				if (state >= 0) {
					if (deg == 0) {
						SDL_RenderCopy(renderer, texture, nullptr, &disprect);
					}
					else {
						SDL_RenderCopyEx(renderer, texture, nullptr, &disprect, deg, &rotpoint, SDL_FLIP_NONE);
					}
				}
				else if (state == -1) {//FLIP VERTICALLY
					SDL_RenderCopyEx(renderer, texture, nullptr, &disprect, deg, &rotpoint, SDL_FLIP_VERTICAL);
				}
				else if (state == -2) {//FLIP HORIZONTALLY
					SDL_RenderCopyEx(renderer, texture, nullptr, &disprect, deg, &rotpoint, SDL_FLIP_HORIZONTAL);
				}
			}
			//std::cout << "y" << y;

		}
	}
}

void Texture::Cleanup() {
	if (texture) {
		SDL_DestroyTexture(texture);
		texture = nullptr;
	}
}

int Texture::GetDimension(int height_1_width_2) {
	if (height_1_width_2 == 1) {
		return baserect.h;
	}
	else if (height_1_width_2 == 2) {
		return baserect.w;
	}
}