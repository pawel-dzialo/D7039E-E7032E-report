#pragma once
#include <string>
#include <vector>
#include "Texture.h"

unsigned char FlipByte(unsigned char my_byte);

class Electrode
{
public:
	std::string label;
	std::string transducer_type;
	std::string physical_dimension;
	float physical_minimum;
	float physical_maximum;
	int digital_minimum;
	int digital_maximum;
	std::string prefiltering;
	int samples_per_second;
	std::string reserved;
	std::vector<short> data;
private:

};

class DataWindow
{
public:
	std::vector<short>* data;
	int label = 0;
	int X = 0;
	int Y = 0;
	//void Disp(int y, int x, int h, int w);
	//void MakeSprite();
private:
	//Texture* sprite;
};

class Dataset
{
public:
	void ImportEDF(std::string filename);//forts�tt att ladda in filer
	void DispWindow(int num);
	Texture* GetWindowTexture(int label, int num = -1);//num = -1 means random
	void LoadLabels(std::string filename);//ladda .seizures
	void MakeWindows();//offsetta l�ngsammare p� labellade omr�den f�r att f� fler labels d�r
	void SortDataset();//sortera datasettet efter labels, stoppa in datapunkter i datawindow_label[r�tt label]
	void RemoveJunk();
	void BalanceDataset();//ta bort (random) dataframes tills settet �r balanserat
	void ExportData(std::string filename);
	void Cleanup();
	double datasetsize = 0;
private:
	void RecountSize() {
		double buf = datawindow.size();
		if (datawindow_label[0] && datawindow_label[1] && datawindow_label[2]) {
			buf += datawindow_label[0]->size();
			buf += datawindow_label[1]->size();
			buf += datawindow_label[2]->size();
		}
		datasetsize = buf;
	}
	std::vector<Electrode*> electrode;
	std::vector<DataWindow*> datawindow;
	std::vector<DataWindow*>* datawindow_label[3];
	std::vector<int> seizurecoords;
	int preictal_time_in_seconds = 300;
	int windowwidth = 256;
};

