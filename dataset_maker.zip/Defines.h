#pragma once

#define tickspeed 60

#define menustylesize 32