#pragma once

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <string>
#include <vector>
#include <windows.h>
#include <thread>

#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL_net.h>

#ifdef _DEBUG
#undef _DEBUG
#include <Python.h>
#define _DEBUG
#else
#include <Python.h>
#endif

#include "Defines.h"
#include "Texture.h"
#include "Text.h"
#include "UIobj.h"

#include "Dataset.h"

#include "Preprocessing.h"

SDL_Renderer* renderer = nullptr;
SDL_Window* window = nullptr;
SDL_Event mainevent;
TTF_Font* CardoB;

SDL_Color Black = { 0,0,0 };

Dataset data;
Preprocessing preprocessing;

int screenh = 1080;
int screenw = 1920;

int mY = 0;
int mX = 0;

unsigned char clickbuffer[256] = {0};

unsigned char threadcontroller = 0;
unsigned char threadrunning_python = 0;
unsigned char threadrunning_dataset = 0;

std::vector<UIobj*> menu;
std::vector<Dataset*> dataset;

Texture* windowtexture = nullptr;
Texture* labeltexture = nullptr;