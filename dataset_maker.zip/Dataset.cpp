#include "Dataset.h"

#include <fstream>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <windows.h>

#include "Preprocessing.h"
//#include "fastICA.h"

extern Preprocessing preprocessing;

//std::string label;
//std::string transducer_type;
//std::string physical_dimension;
//float physical_minimum;
//float physical_maximum;
//int digital_minimum;
//int digital_maximum;
//std::string prefiltering;
//int samples;
//std::string reserved;

#define maxsamples 921600

unsigned char FlipByte(unsigned char my_byte) {
	unsigned char ret = (my_byte & 0b00000001) << 7;
	ret = ret | (my_byte & 0b00000010) << 5;
	ret = ret | (my_byte & 0b00000100) << 3;
	ret = ret | (my_byte & 0b00001000) << 1;
	ret = ret | (my_byte & 0b00010000) >> 1;
	ret = ret | (my_byte & 0b00100000) >> 3;
	ret = ret | (my_byte & 0b01000000) >> 5;
	ret = ret | (my_byte & 0b10000000) >> 7;
	return ret;
}

double** DataWindow::to_array() {
	if (data) {
		double** M;

		M = (double**)malloc(Y * sizeof(double*));
		for (int a = 0; a < Y; a++) {
			M[a] = (double*)malloc(X * sizeof(double));
			for (int b = 0; b < X; b++) {
				M[a][b] = (double)((short)(*data)[a * X + b]);
			}
		}
		return M;
	}
	else {
		return 0;
	}
}

void DataWindow::preprocess() {
	if (false) {//ha inte med preprocessing
		double** M = to_array();//initialize M
		double buf = 0;
		double highest = 0;
		double lowest = 0;
		double scalefactor = 1;
		M = preprocessing.fast_ica(M, Y, X);

		//for (int a = 0; a < Y; a++) {
		//	for (int b = 0; b < X; b++) {
		//		if (M[a][b] > highest) {
		//			highest = M[a][b];
		//		}
		//		else if (M[a][b] < lowest) {
		//			lowest = M[a][b];
		//		}
		//	}
		//}
		//if (-lowest > highest) {
		//	highest = -lowest;
		//}
		//if (highest > 0) {
		//	scalefactor = 32767 / highest;
		//}
		for (int a = 0; a < Y; a++) {
			for (int b = 0; b < X; b++) {
				buf = (double)M[a][b] * scalefactor;
				(*data)[a * X + b] = (short)buf;
			}
		}
		for (int a = 0; a < Y; a++) {//delete M
			free(M[a]);
		}
		free(M);
	}
}

void Dataset::ImportEDF(std::string filename) {
	FILE* file;
	fopen_s(&file, filename.c_str(), "rb");
	unsigned char buf[256];
	char nsbuf[5] = { 0 };
	int ns;
	int my_electrode;
	unsigned short val;
	int count = 0;
	if (file) {
		//HEADER-----------------------------------------------------------------------------------
		//header described here: https://www.teuniz.net/edfbrowser/edf%20format%20description.html
		fread_s(buf, sizeof(buf), 1, 8, file);//8 ascii version of this data format (0)
		fread_s(buf, sizeof(buf), 1, 80, file);//80 ascii local patient identification
		fread_s(buf, sizeof(buf), 1, 80, file);//80 ascii local recording identification
		fread_s(buf, sizeof(buf), 1, 8, file);//8 ascii startdate of recording (dd.mm.yy)
		fread_s(buf, sizeof(buf), 1, 8, file);//8 ascii starttime of recording (hh.mm.ss)
		fread_s(buf, sizeof(buf), 1, 8, file);//8 ascii number of bytes in header record
		fread_s(buf, sizeof(buf), 1, 44, file);//44 ascii reserved
		fread_s(buf, sizeof(buf), 1, 8, file);//8 ascii number of data records (-1 if unknown)
		fread_s(buf, sizeof(buf), 1, 8, file);//8 ascii duration of a data record, in seconds
		fread_s(nsbuf, sizeof(nsbuf), 1, 4, file);//4 ascii number of signals (ns) in data record
		ns = atoi(nsbuf);
		if (ns > 0 && ns <= 256) {//hardlimit on 256 electrodes
			//std::cout << ns << " electrodes\n";
			for (int a = 0; a < ns; a++) {
				electrode.push_back(new Electrode);
			}
			for (int a = 0; a < ns; a++) {
				if (electrode.size() > a && electrode[a]) {
					electrode[a]->data.reserve(maxsamples);
				}
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 16, file);//ns * 16 ascii ns * label (e.g. EEG FpzCz or Body temp)
			if (electrode.size() > a && electrode[a]) {
				buf[16] = '\0';
				electrode[a]->label = (char*)buf;
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 80, file);//ns * 80 ascii ns * transducer type (e.g. AgAgCI electrode)
			if (electrode.size() > a && electrode[a]) {
				buf[80] = '\0';
				electrode[a]->transducer_type = (char*)buf;
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 8, file);//ns * 8 ascii ns * physical dimension(e.g. uV or degree C)
			if (electrode.size() > a && electrode[a]) {
				buf[8] = '\0';
				electrode[a]->physical_dimension = (char*)buf;
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 8, file);//ns * 8 ascii ns * physical minimum (e.g. -500 or 34)
			if (electrode.size() > a && electrode[a]) {
				buf[8] = '\0';
				electrode[a]->physical_minimum = atof((char*)buf);
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 8, file);//ns * 8 ascii ns * physical maximum (e.g. 500 or 40)
			if (electrode.size() > a && electrode[a]) {
				buf[8] = '\0';
				electrode[a]->physical_maximum = atof((char*)buf);
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 8, file);//ns * 8 ascii ns * digital minimum (e.g. -2048)
			if (electrode.size() > a && electrode[a]) {
				buf[8] = '\0';
				electrode[a]->digital_minimum = atoi((char*)buf);
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 8, file);//ns * 8 ascii ns * digital maximum (e.g. 2047)
			if (electrode.size() > a && electrode[a]) {
				buf[8] = '\0';
				electrode[a]->digital_maximum = atoi((char*)buf);
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 80, file);//ns * 80 ascii ns * prefiltering (e.g. HP:0.1Hz LP:75Hz)
			if (electrode.size() > a && electrode[a]) {
				buf[80] = '\0';
				electrode[a]->prefiltering = (char*)buf;
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 8, file);//ns * 8 ascii ns * nr of samples in each data record
			if (electrode.size() > a && electrode[a]) {
				buf[8] = '\0';
				electrode[a]->samples_per_second = atoi((char*)buf);
			}
		}
		for (int a = 0; a < ns; a++) {
			fread_s(buf, sizeof(buf), 1, 32, file);//ns * 32 ascii ns * reserved
			if (electrode.size() > a && electrode[a]) {
				buf[32] = '\0';
				electrode[a]->reserved = (char*)buf;
			}
		}
		
		//ACTUAL DATA------------------------------------------------------------------------------
		for (int a = 0; a < ns; a++) {
			if (electrode.size() > a && electrode[a]) {
				//reserve data
				electrode[a]->data.reserve(maxsamples);
				//std::cout << electrode[a]->physical_maximum << "\n";
			}
		}
		while (fread_s(buf, sizeof(buf), 1, 2, file) == 2) {
			val = buf[0] << 8;
			val = val | (unsigned short)buf[1];
			//std::cout << (signed short)val << " " << count << "\n";

			my_electrode = count / maxsamples;
			if (my_electrode >= 0 && my_electrode < electrode.size()) {
				electrode[my_electrode]->data.push_back(val);
			}

			if (count % 1000000 == 0) {
				std::cout << count << "\n";
			}
			count++;
		}
		if (feof(file)) {
			//ok
		}
		else {
			//file closed before end of file
		}
		if (ns != 0) {
			std::cout << count << " = " << ns << " x " << count / ns << "\n";
		}
		fclose(file);
	}
	else {
		std::cout << "Could not open file\n";
	}
}

int Dataset::GetRandomWindow(int label) {
	if (label >= 0 && label <= 3) {
		if (datawindow_label[label] && datawindow_label[label]->size() > 0) {
			return rand() % datawindow_label[label]->size();
		}
	}
	return 0;
}

Texture* Dataset::GetWindowTexture(int label, int num) {
	if (label == -1) {
		label = rand() % 3;
	}
	if (label >= 0 && label <= 3) {
		//make texture from pixels
		if (datawindow_label[label] && datawindow_label[label]->size() > 0) {
			if (num == -1) {
				num = GetRandomWindow(label);
			}
			if (num >= 0 && num < datawindow_label[label]->size() && (*datawindow_label[label])[num]) {
				if ((*datawindow_label[label])[num]->data && (*datawindow_label[label])[num]->data->size() == (*datawindow_label[label])[num]->Y * (*datawindow_label[label])[num]->X) {
					SDL_Surface* surface = SDL_CreateRGBSurfaceWithFormat(0, (*datawindow_label[label])[num]->X, (*datawindow_label[label])[num]->Y, 32, SDL_PIXELFORMAT_RGBA32);
					if (surface) {
						uint8_t* pixels = (uint8_t*)surface->pixels;
						if (pixels) {
							for (int a = 0; a < (*datawindow_label[label])[num]->Y; a++) {
								for (int b = 0; b < (*datawindow_label[label])[num]->X; b++) {

									int buf = 32768 + (int)(*(*datawindow_label[label])[num]->data)[a * (*datawindow_label[label])[num]->X + b];
									buf = buf / 256;

									pixels[4 * (a * (*datawindow_label[label])[num]->X + b) + 0] = (unsigned char)buf;
									pixels[4 * (a * (*datawindow_label[label])[num]->X + b) + 1] = (unsigned char)buf;
									pixels[4 * (a * (*datawindow_label[label])[num]->X + b) + 2] = (unsigned char)buf;
									pixels[4 * (a * (*datawindow_label[label])[num]->X + b) + 3] = 255;
								}
							}
							Texture* texture = new Texture;
							texture->FromSurface(surface);
							SDL_FreeSurface(surface);
							return texture;
						}
						SDL_FreeSurface(surface);
					}
				}
			}
		}
	}
	return nullptr;
}

void Dataset::LoadLabels(std::string filename) {

	unsigned char buf[256];
	int startval = 0;
	int endval = 0;

	filename = filename + ".seizures";
	FILE* file;
	fopen_s(&file, filename.c_str(), "rb");

	seizurecoords.clear();

	if (file) {
		fread_s(buf, sizeof(buf), 1, 34, file);//header
		int val = 0;
		bool loop = true;
		while (loop) {
			if (fread_s(buf, sizeof(buf), 1, 1, file) == 1) {
				val = val << 8 | buf[0];
				//std::cout << std::hex << val << "\n";
				//std::cout << std::dec << val << "\n";
				if (val == 16777452) {//signature, ok
					fread_s(buf, sizeof(buf), 1, 16, file);//contents described below (source: pawels python code)
					// [0]	msb of seizure offset in seconds
					// [1]	skip
					// [2]	skip
					// [3]	lsb of seizure offset in seconds
					// [4]	skip
					// [5]	skip
					// [6]	skip
					// [7]	skip
					// [8]	skip
					// [9]	skip
					// [10]	skip
					// [11]	length of seizure in seconds
					// [12]	skip
					// [13]	skip
					// [14]	skip
					// [15]	skip

					startval = buf[0] << 8 | buf[3];
					//curtime += startval;
					seizurecoords.push_back(startval * 256);

					endval = startval + (int)buf[11];
					//curtime += (int)buf[11];
					seizurecoords.push_back(endval * 256);

					//if (endian == big) {
					//	buf[2] = FlipByte(buf[0]);
					//	buf[0] = FlipByte(buf[1]);
					//	buf[1] = buf[2];
					//}
				}
				else {
					//keep going
				}
			}
			else {
				loop = false;
			}
		}
		fclose(file);
	}
	if (seizurecoords.size() >= 2) {
		std::cout << "From " << seizurecoords[0] << " to " << seizurecoords[1] << "\n";

	}
}

void Dataset::LabelWindows() {
	if (seizurecoords.size() >= 2) {
		for (int a = 0; a < datawindow.size(); a++) {
			if (datawindow[a] && datawindow[a]->data) {
				if (a * 256 >= seizurecoords[0] && a * 256 <= seizurecoords[1]) {
					datawindow[a]->label = 2;
				}
				else if (a * 256 >= seizurecoords[0] - preictal_time_in_seconds * 256 && a * 256 < seizurecoords[0]) {
					datawindow[a]->label = 1;
				}
				else {
					datawindow[a]->label = 0;
				}
			}
		}
	}
}

void Dataset::MakeWindows(bool keep_all_zeros) {
	//def MakeDataWindows(data, channels, xsize, out_data) :
	//	s = (int(channels), int(xsize))
	//	scaledata = 1000
	//	pic = np.zeros(s)
	//	#print(pic[22][22])
	//	print(f'Running for {int(data.size/xsize/channels)} iterations')
	//	for i in range(int(data.size / xsize / channels)) :
	//		for j in range(int(channels)) :
	//			for k in range(int(xsize)) :
	//				pic[j][k] = float(data[j][int(i * xsize + k)]) * 1000
	//				out_data.append(pic)
	//				print(
	//					f'\rLoop {i}',
	//					end = ''
	//				)
	//				print(f'\nLoop Complete\n')
	int ns = electrode.size();
	int sample_size = maxsamples;
	for (int a = 0; a < ns; a++) {
		if (electrode[a]) {
			//std::cout << electrode[a]->data.size() << " samples\n";
			if (electrode[a]->data.size() == sample_size) {
				//ok
			}
			else {
				sample_size = 0;
			}
		}
	}
	int offset;
	int labelgroup = 0;
	bool do_preprocess = false;//enable/disable preprocessing
	bool only_100_datawindows = false;
	if (sample_size > 0 && windowwidth > 0) {
		for (int a = 0; a < sample_size / windowwidth - 1; a++) {//for safety, a -1
			if (only_100_datawindows == false || datasetsize < 100) {
				datawindow.push_back(new DataWindow);
				datawindow.back()->data = new std::vector<short>;
				datawindow.back()->data->reserve(ns * windowwidth);
				datawindow.back()->Y = windowwidth;
				datawindow.back()->X = ns;
				if (seizurecoords.size() > 0) {
					if (a * windowwidth >= seizurecoords[0] && a * windowwidth <= seizurecoords[1]) {//ictal
						labelgroup = 2;
					}
					else if (a * windowwidth < seizurecoords[0] && a * windowwidth + preictal_time_in_seconds * 256 >= seizurecoords[0]) {//pre-ictal
						labelgroup = 1;
					}
					else if (a * windowwidth < seizurecoords[0] && a * windowwidth + interictal_time_in_seconds * 256 < seizurecoords[0]) {//inter-ictal, do not count "ambiguous" data between 5 and 30 min before seizure, also do not count data after seizure
						labelgroup = 0;
					}
				}
				else {
					labelgroup = 0;
				}
				datawindow.back()->label = labelgroup;
				if (labelgroup == 0) {
					if (rand() % 4 == 0 || keep_all_zeros) {//only keep 1/4 of the data, unless it is specified to keep all zeros
						for (int b = 0; b < windowwidth; b++) {//timestep
							offset = b + a * windowwidth;
							for (int c = 0; c < ns; c++) {//electrode
								if (offset < electrode[c]->data.size() && offset >= 0) {
									datawindow.back()->data->push_back(electrode[c]->data[offset]);
								}
							}
						}
						if (do_preprocess) {
							datawindow.back()->preprocess();
						}
					}
					else {//delete the window
						delete datawindow.back()->data;
						delete datawindow.back();
						datawindow.pop_back();
					}
				}
				else if (labelgroup == 1) {
					for (int xoffset = 0; xoffset < 8; xoffset++) {//make 8x as many datawindows
						if (xoffset != 0) {
							datawindow.push_back(new DataWindow);
							datawindow.back()->data = new std::vector<short>;
							datawindow.back()->data->reserve(ns * windowwidth);
							datawindow.back()->Y = windowwidth;
							datawindow.back()->X = ns;
							datawindow.back()->label = labelgroup;
						}
						for (int b = 0; b < windowwidth; b++) {//timestep
							offset = b + a * windowwidth + xoffset * windowwidth / 8;
							for (int c = 0; c < ns; c++) {//electrode
								if (offset < electrode[c]->data.size() && offset >= 0) {
									datawindow.back()->data->push_back(electrode[c]->data[offset]);
								}
							}
						}
						if (do_preprocess) {
							datawindow.back()->preprocess();
						}
					}
				}
				else if (labelgroup == 2) {
					for (int xoffset = 0; xoffset < 4; xoffset++) {//make 4x as many datawindows
						if (xoffset != 0) {
							datawindow.push_back(new DataWindow);
							datawindow.back()->data = new std::vector<short>;
							datawindow.back()->data->reserve(ns * windowwidth);
							datawindow.back()->Y = windowwidth;
							datawindow.back()->X = ns;
							datawindow.back()->label = labelgroup;
						}
						for (int b = 0; b < windowwidth; b++) {//timestep
							offset = b + a * windowwidth + xoffset * windowwidth / 4;
							for (int c = 0; c < ns; c++) {//electrode
								if (offset < electrode[c]->data.size() && offset >= 0) {
									datawindow.back()->data->push_back(electrode[c]->data[offset]);
								}
							}
						}
						if (do_preprocess) {
							datawindow.back()->preprocess();
						}
					}
				}
				RecountSize();
			}
		}
	}
	std::cout << datawindow.size() << " datawindows\n";
}

void Dataset::DispWindow(int num) {
	if (num >= 0 && num < datawindow.size() && datawindow[num] && datawindow[num]->Y * datawindow[num]->X == datawindow[num]->data->size()) {
		for (int a = 0; a < datawindow[num]->Y; a++) {
			for (int b = 0; b < datawindow[num]->X; b++) {
				std::cout << (*datawindow[num]->data)[datawindow[num]->X * a + b] << " ";
			}
			std::cout << "\n";
		}
	}
}

void Dataset::SortDataset() {
	for (int a = 0; a < 3; a++) {
		if (!datawindow_label[a]) {
			datawindow_label[a] = new std::vector<DataWindow*>;
		}
		for (int b = 0; b < datawindow.size(); b++) {
			if (datawindow[b]->label == a) {
				datawindow_label[a]->push_back(datawindow[b]);
			}
		}
		std::cout << datawindow_label[a]->size() << " datawindows with label " << a << "\n";
	}
}

void Dataset::RemoveJunk() {
	datawindow.clear();//all information is stored in the label-specific vectors
	for (int a = 0; a < electrode.size(); a++) {
		if (electrode[a]) {
			electrode[a]->data.clear();//should be handled automatically when deleting electrode[a]
			delete electrode[a];
			electrode[a] = nullptr;
		}
	}
	electrode.clear();
}

void Dataset::BalanceDataset() {
	if (datawindow_label[0] && datawindow_label[1] && datawindow_label[2]) {
		//find the lowest of the 3
		int lowest = datawindow_label[0]->size();
		if (datawindow_label[1]->size() < lowest) {
			lowest = datawindow_label[1]->size();
		}
		if (datawindow_label[2]->size() < lowest) {
			lowest = datawindow_label[2]->size();
		}
		//remove random datawindows until they're balanced
		if (lowest > 0) {
			std::cout << "Reducing datawindows to " << lowest << " per label\n";
			int num = 0;
			for (int a = 0; a < 3; a++) {
				while (datawindow_label[a]->size() > lowest) {
					num = rand() % datawindow_label[a]->size();
					delete (*datawindow_label[a])[num]->data;
					datawindow_label[a]->erase(datawindow_label[a]->begin() + num);//quite a time-consuming operation
				}
				std::cout << datawindow_label[a]->size() << " datawindows with label " << a << "\n";
			}
		}
		else {
			//nothing to balance yet
		}
	}
	RecountSize();
}

void Dataset::ExportData(std::string filename) {
	if (datawindow_label[0] && datawindow_label[1] && datawindow_label[2]) {

		std::vector<short>* data;

		FILE* file;
		fopen_s(&file, filename.c_str(), "w");

		if (file) {
			RecountSize();
			double buf = datasetsize;
			int done = 0;
			for (int a = 0; a < 3; a++) {
				for (int b = 0; b < datawindow_label[a]->size(); b++) {
					datasetsize = (double)done / buf;
					if ((*datawindow_label[a])[b]) {
						fputs(std::to_string((*datawindow_label[a])[b]->label).c_str(), file);
						fputs(" ", file);
						data = (*datawindow_label[a])[b]->data;
						if (data) {
							for (int c = 0; c < data->size(); c++) {
								fputs(std::to_string((*data)[c]).c_str(), file);
								fputs(" ", file);
							}
							done++;
						}
					}
					fputs("\n", file);
				}
			}
			RecountSize();
			fclose(file);
			std::cout << "Exported file\n";
		}
		else {
			std::cout << "No file object\n";
		}
	}
	else {
		std::cout << "Exporting from datawindow\n";
		if (datawindow.size() > 0) {
			std::vector<short>* data;

			FILE* file;
			fopen_s(&file, filename.c_str(), "w");

			if (file) {
				RecountSize();
				double buf = datasetsize;
				int done = 0;
				for (int b = 0; b < datawindow.size(); b++) {
					datasetsize = (double)done / buf;
					if (datawindow[b]) {
						fputs(std::to_string(datawindow[b]->label).c_str(), file);
						fputs(" ", file);
						data = datawindow[b]->data;
						if (data) {
							for (int c = 0; c < data->size(); c++) {
								fputs(std::to_string((*data)[c]).c_str(), file);
								fputs(" ", file);
							}
							done++;
						}
					}
					fputs("\n", file);
				}
				RecountSize();
				fclose(file);
				std::cout << "Exported file\n";
			}
			else {
				std::cout << "No file object\n";
			}
		}
		else {
			std::cout << "No data\n";
		}
	}
}

void Dataset::Cleanup() {
	RemoveJunk();
}
