#include "Text.h"
#include <iostream>

#include "Texture.h"
extern SDL_Texture* testtexture;

extern SDL_Color Black;
//extern TTF_Font* Cardo;
extern TTF_Font* CardoB;
//extern TTF_Font* Sans;

extern SDL_Renderer* renderer;

extern int screenh;
extern int screenw;

void NumToString(std::string* text, double* tracked_val) {
	if (tracked_val) {
		double my_val = *tracked_val;
		*text = *text + std::to_string((int)(my_val));
		double next_val = (int)(my_val);
		if (my_val > next_val) {
			*text = *text + ".";
			for (int a = 1; a < 3; a++) {
				//std::cout << *tracked_val;
				//std::cout << ">" << next_val << "?";
				if (*tracked_val > next_val) {
					//std::cout << " yes\n";
					my_val = (int)((*tracked_val - next_val) * pow(10, a));
					next_val = next_val + my_val / pow(10, a);
					*text = *text + std::to_string((int)(my_val));
					//new_val = new_val + (double)((int)((double)((*my_val - new_val) * pow(10, a)))) / pow(10, a);
					//*text = *text + std::to_string((int)(((double)((*my_val - new_val) * pow(10, a))) / pow(10, a)));
				}
				else {
					//std::cout << " no\n";
					a = 15;//break loop
				}
			}
		}
		//*text = std::to_string(*my_val);
	}
}

void Text::Clear() {
	str.str(std::string());
}

int Text::Print(int y, int x, int size, int rY, int rX, int rH, int rW) {
	//Same code base as previous template
	disprect.y = y;
	disprect.x = x;
	if (size < 6) {//lower limit for text size
		size = 6;
	}
	if (size >= 300) {//upper limit for text size
		size = 300;
	}
	SDL_Surface* textSurface = TTF_RenderText_Blended(*font, str.str().c_str(), color);
	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");
	Message = SDL_CreateTextureFromSurface(renderer, textSurface);
	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
	SDL_QueryTexture(Message, NULL, NULL, &disprect.w, &disprect.h);
	if (disprect.h > 0) {
		disprect.w = disprect.w * size / disprect.h;
		disprect.h = size;
	}
	else {
		std::cout << disprect.h << " " << disprect.x << "\n";
	}
	Disp(y, x, rY, rX, rH, rW);
	SDL_FreeSurface(textSurface);
	SDL_DestroyTexture(Message);
	return x + disprect.w;// +size;
}

void Text::NewLabel(std::string text, int size, TTF_Font** Font, SDL_Color Color, double* tracking_number, std::string* label_ptr) {
	if (size < 0) {//negative size means print a generic background for the text. Mainly for testing and bugtesting (removed)
		size = -size;
		//usebackground = true;
	}
	if (size < 6) {//lower limit for text size
		size = 6;
	}
	if (size >= 300) {//upper limit for text size
		size = 300;
	}
	labelsize = size;
	labelname = text;
	labelptr = label_ptr;
	if (label_ptr) {
		text = *label_ptr;
	}
	if (tracking_number) {
		trackingnum = tracking_number;
		trackingnumold = *tracking_number;
		std::string buf = text;
		NumToString(&buf, trackingnum);
		text = buf;
	}
	else {
		trackingnum = nullptr;
	}
	font = Font;
	color = Color;
	if (text.length() > 0) {
		//std::cout << "<" << text << ">\n";
		SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");
		SDL_Surface* textSurface = TTF_RenderText_Blended(*font, text.c_str(), color);
		//if (textSurface == NULL) {
		//	std::cout << "NO ";
		//}
		//Message = new SDL_Texture*;
		if (Message) {
			SDL_DestroyTexture(Message);
			Message = nullptr;
		}
		Message = SDL_CreateTextureFromSurface(renderer, textSurface);
		SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
		int r = SDL_QueryTexture(Message, NULL, NULL, &disprect.w, &disprect.h);
		//std::cout << text;
		if (disprect.h > 0) {
			disprect.w = disprect.w * size / disprect.h;
			disprect.h = size;
			//std::cout << text;
		}
		else {
			//std::cout << disprect.h << " " << disprect.x << " R" << r << "\n";
			disprect.w = 0;
			disprect.h = 0;
		}
		SDL_FreeSurface(textSurface);
	}
}

void Text::PrintLabel(int y, int x, int rY, int rX, int rH, int rW) {


	Disp(y, x, 1);
}

void Text::Disp(int y, int x, double size, int rY, int rX, int rH, int rW) {

	if (trackingnum && *trackingnum != trackingnumold) {
		trackingnumold = *trackingnum;
		double* sendbuf = trackingnum;
		Cleanup();
		NewLabel(labelname, labelsize, font, color, sendbuf);
	}
	if (labelptr && *labelptr != labelname) {
		labelname = *labelptr;
		double* sendbuf = trackingnum;
		Cleanup();
		NewLabel(labelname, labelsize, font, color, sendbuf, labelptr);
	}
	if (trackingnum) {
		//std::cout << *trackingnum << "\n";
	}

	if (rH <= 0) {
		rH = screenh;
	}
	if (rW <= 0) {
		rW = screenw;
	}

	disprect.y = y;
	disprect.x = x;
	int h, w;
	h = disprect.h;
	w = disprect.w;
	disprect.h = size * h;
	disprect.w = size * w;

	SDL_RenderCopy(renderer, Message, NULL, &disprect);

	disprect.h = h;
	disprect.w = w;

}

void Text::DispCenter(int y, int x, double size, int rY, int rX, int rH, int rW) {
	Disp(y - disprect.h / 2 * size, x - disprect.w / 2 * size, size, rY, rX, rH, rW);
}

void Text::SetColor(int r, int g, int b, int a) {
	color.r = r;
	color.g = g;
	color.b = b;
	color.a = a;
}

bool Text::HasText() {
	if (disprect.w > 0) {
		return true;
	}
	return false;
}

void Text::Cleanup() {
	if (Message) {
		SDL_DestroyTexture(Message);
		Message = nullptr;
	}
	//disprect.w = 0;
	//disprect.h = 0;
}