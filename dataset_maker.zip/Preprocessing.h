#pragma once
class Preprocessing
{
public:
	unsigned int* decimation_CIC(unsigned int* input, int size, int D);
	double** fast_ica(double** input_array, int input_rows, int input_cols);
};

