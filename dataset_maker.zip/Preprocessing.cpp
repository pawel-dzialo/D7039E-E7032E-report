#include "Preprocessing.h"

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include "libICA.h"
#include "matrix.h"

//code below doesn't work and isn't used:
////Function that uses CIC filter for decimation
////Author: Michelle von Rosen
////Date: November 2022
//
//#include <stdio.h>
//#include <stdlib.h>
//#include <stdint.h>
//
//static const int end_const = 256;
//
//unsigned int* Preprocessing::decimation_CIC(unsigned int* input, int size, int D) {
//    // size = size of input array, D = decimation factor, N = delay buffer depth
//    //int end_const = size / D;  // OBS! Must return an integer, change N & D accordingly
//    int outIndex = 0;
//    uint32_t intOut = 0;
//    uint32_t combOut = 0;
//    uint32_t delayBuffer[end_const];
//    uint32_t tempBuffer[end_const];
//    uint32_t* output = (uint32_t*)malloc(sizeof(uint32_t) * end_const);
//
//    // initializing the buffer with zeros
//    for (int i = 0; i < end_const; i++) {
//        delayBuffer[i] = 0;
//    }
//
//    // CIC algorithm loop
//    for (int i = 0; i < size; i++) {
//        // integrator
//        intOut = intOut + input[i];
//
//        // decimation
//        if ((i + 1) % D == 1) {
//            //comb section
//            combOut = intOut - delayBuffer[end_const - 1];
//
//            // push values in array to the right i.e updating buffer
//            for (int j = 1; j < end_const; j++) {
//                tempBuffer[j] = delayBuffer[j - 1];
//            }
//            for (int k = 1; k < end_const; k++) {
//                delayBuffer[k] = tempBuffer[k];
//
//            }
//            delayBuffer[0] = intOut;
//            output[outIndex] = combOut;
//            outIndex++;
//        }
//
//    }
//    // FIR Compensation Filter
//    uint32_t firOut[end_const - 1];
//    uint32_t old = 0;
//    int firIndex = 0;
//
//    // removing first 2 values since they have unexpected filter behaviour
//    for (int i = 2; i < end_const; i++) {
//        // FIR algorithm
//        // "multiplying" the second newest value with 18 (2^4+2^1)
//        // 18 for first order CIC-filter, use 10 for 2-3th order filter
//        old = (output[i - 1] >> 4) + (output[i - 1] >> 1);
//        firOut[firIndex] = output[i] + output[i - 2] - old;
//
//        // only for printing answer (testing)
//        printf("%d, ", firOut[firIndex]);
//        firIndex++;
//    }
//
//    return output;
//}
//
////int main()
////{
////    uint32_t data[] = { 0,1,2,3,4,5,6,7,8,9,8,7,6,5,4,3,2,1,0,1,2,3,4,5,6,7,8,9,
////        8,7,6,5,4,3,2,1,0,1,2,3,4,5,6,7,8,9,8,7,6,5 };
////    int dataPoints = sizeof(data) / sizeof(data[0]);
////    int decimation = 5;
////    int bufferSize = 10;
////    static uint32_t* filtered_ptr;
////
////    filtered_ptr = decimation_CIC(data, dataPoints, decimation);
////    return 0;
////}



//static double** mat_create(int rows, int cols)
//{
//	double **m; int i;
//	
//	m = (double**) malloc(rows * sizeof(double*));
//	for (i=0; i<rows; i++)
//		m[i] = (double*) malloc(cols * sizeof(double));
//	
//	return m;
//}

static void mat_print(double** M, int rows, int cols)
{
	int i, j;

	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			printf("%0.6f", M[i][j]);
			if (j < cols - 1)
				printf(" ");
		}
		printf("\n");
	}
}

double** Preprocessing::fast_ica(double** input_array, int input_rows, int input_cols)
{
	double** X, ** K, ** W, ** A, ** S;
	int rows = input_rows;
	int cols = input_cols;
	int compc;
	//FILE *fp;

	//// Input parameters check
	//if (argc == 2) {
	//	if ((fopen_s(&fp, argv[1], "r")) == NULL) {//MANUALLY EDITED FROM (fp = fopen(argv[1], "r")) == NULL
	//		perror("Error opening input file");
	//		exit(-1);
	//	}
	//} else {	
	//	printf("usage: %s data_file\n", argv[0]);
	//	exit(-1);
	//}

	compc = 23;

	// Matrix creation
	//X = mat_read(fp, &rows, &cols);
	X = input_array;
	W = mat_create(compc, compc);
	//W = mat_create(rows, cols);//s� att man kan returnera
	A = mat_create(compc, compc);
	K = mat_create(cols, compc);
	S = mat_create(rows, cols);

	// ICA computation
	fastICA(X, rows, cols, compc, K, W, A, S);

	// Output
	//printf("$K\n");
	//mat_print(K, cols, compc);

	//printf("\n$W\n");
	//mat_print(W, compc, compc);

	//printf("\n$A\n");
	//mat_print(A, compc, compc);

	//printf("\n$S\n");
	//mat_print(S, rows, compc);

	return X;//Michelle sa att X var output (men det �r input)
}