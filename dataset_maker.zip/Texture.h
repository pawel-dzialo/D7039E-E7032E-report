#pragma once
#include <string>
#include <SDL.h>
#include <SDL_image.h>

class Texture
{
public:
	void LoadTexture(std::string filename);
	void FromSurface(SDL_Surface* surface);
	void Label(std::string text);
	void RedSwapLoad(std::string filename, int R, int G, int B, int A = 255);//Pure red gets turned into specified color. Pure green is a lightened and pure blue is a darkened version of the color. Initially loaded picture has to have an alpha channel enabled for the new texture to have it. (SDL's fault, not mine)
	void MakeMenu(std::string style, int H, int W, int exitnum = 0);// exitnum: 1=up right, 2=down right, 3=down left, 4=up left, 0=no exit button
	SDL_Texture* StealTexture();//Remember to cleanup manually
	void Disp(int y, int x, int h, int w, double deg = 0, int roty = 0, int rotx = 0, int state = 0, int animationwidth = -1);
	void Cleanup();
	int GetDimension(int height_1_width_2);
	~Texture() {
		Cleanup();
	}
private:
	SDL_Texture* texture = nullptr;
	SDL_Rect disprect = { 0,0,0,0 };
	SDL_Rect animationrect = { 0,0,0,0 };
	SDL_Rect baserect = { 0,0,0,0 };
	SDL_Point rotpoint = { 0,0 };
};