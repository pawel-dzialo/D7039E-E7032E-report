//#pragma once
//
//class FastICA
//{
//public:
//	double** fast_ica(double** input_array, int input_rows, int input_cols);
//};