#pragma once
#include <SDL.h>
#include <SDL_ttf.h>
#include <sstream>

void NumToString(std::string* text, double* tracked_val);

class Text
{
public:
	std::stringstream str;
	void Clear();//destroy the existing textstream to start fresh
	int Print(int y, int x, int size, int rY = 0, int rX = 0, int rH = 0, int rW = 0);//print the textstream, return the end position of the text. DO NOT USE THIS FUNCTION, IT IS OUTDATED.
	void NewLabel(std::string text, int size, TTF_Font** Font, SDL_Color Color, double* tracking_number = nullptr, std::string* label_ptr = nullptr);
	void PrintLabel(int y, int x, int rY = 0, int rX = 0, int rH = 0, int rW = 0);
	void SetColor(int r, int g, int b, int a = 255);
	void Disp(int y, int x, double size = 1, int rY = 0, int rX = 0, int rH = 0, int rW = 0);
	void DispCenter(int y, int x, double size = 1, int rY = 0, int rX = 0, int rH = 0, int rW = 0);
	bool HasText();
	void Cleanup();
private:
	SDL_Rect disprect;
	SDL_Rect croprect;
	SDL_Color color = { 0,0,0 };
	SDL_Texture* Message = nullptr;
	TTF_Font** font;
	std::string labelname;
	int labelsize;
	double* trackingnum = nullptr;
	std::string* labelptr = nullptr;
	double trackingnumold = 0;
};
